﻿//Last update 2009-12-03 www.zdwrok.cn 智动软件
//自添内容
function addEvent(C,B,A){
	if(C.attachEvent){
		C.attachEvent(B,A)//window.attachEvent("resize",onResize);
	}else {
		C.addEventListener(B,A,false)
	}
};
function G(id)
{
	return document.getElementById(id);
}
function onResize()
{
}


//繁简转换开始
var Default_isFT = 0		//默认是否繁体，0-简体，1-繁体
var StranIt_Delay = 60 //翻译延时毫秒（设这个的目的是让网页先流畅的显现出来）
var StranLink_Obj="简";
//－－－－－－－代码开始，以下别改－－－－－－－
//转换文本
function StranText(txt,toFT,chgTxt)
{
	if(txt==""||txt==null)return ""
	toFT=toFT==null?Default_isFT:toFT
	if(chgTxt)txt=txt.replace((toFT?"简":"繁"),(toFT?"繁":"简"))
	if(toFT){return Traditionalized(txt)}
	else {return Simplized(txt)}
}
//转换对象，使用递归，逐层剥到文本
function StranBody(fobj)
{
	if(typeof(fobj)=="object"){var obj=fobj.childNodes}
	else 
	{
		var tmptxt=StranLink_Obj;//StranLink_Obj.innerHTML.toString();
		if(tmptxt.indexOf("简")<0)
		{
			Default_isFT=1
			//StranLink_Obj.innerHTML=StranText(tmptxt,0,1)
			//StranLink_Obj.title=StranText(StranLink_Obj.title,0,1)
		}
		else
		{
			Default_isFT=0
			//StranLink_Obj.innerHTML=StranText(tmptxt,1,1)
			//StranLink_Obj.title=StranText(StranLink_Obj.title,1,1)
		}
		//setCookie(JF_cn,BodyIsFt,7)
		var editor=document.getElementById("editor_body_area").contentWindow;
		var obj=editor.document.body.childNodes;
		//var obj=document.body.childNodes;
	}
	for(var i=0;i<obj.length;i++)
	{
		var OO=obj.item(i)
		if("||BR|HR|TEXTAREA|".indexOf("|"+OO.tagName+"|")>0)continue;
		if(OO.title!=""&&OO.title!=null)OO.title=StranText(OO.title);
		if(OO.alt!=""&&OO.alt!=null)OO.alt=StranText(OO.alt);
		if(OO.tagName=="INPUT"&&OO.value!=""&&OO.type!="text"&&OO.type!="hidden")OO.value=StranText(OO.value);
		if(OO.nodeType==3){OO.data=StranText(OO.data)}
		else StranBody(OO)
	}

}
function JTPYStr()
{
	return '皑蔼碍爱翱袄奥坝罢摆败颁办绊帮绑镑谤剥饱宝报鲍辈贝钡狈备惫绷笔毕毙闭边编贬变辩辫鳖瘪濒滨宾摈饼拨钵铂驳卜补参蚕残惭惨灿苍舱仓沧厕侧册测层诧搀掺蝉馋谗缠铲产阐颤场尝长偿肠厂畅钞车彻尘陈衬撑称惩诚骋痴迟驰耻齿炽冲虫宠畴踌筹绸丑橱厨锄雏础储触处传疮闯创锤纯绰辞词赐聪葱囱从丛凑窜错达带贷担单郸掸胆惮诞弹当挡党荡档捣岛祷导盗灯邓敌涤递缔点垫电淀钓调迭谍叠钉顶锭订东动栋冻斗犊独读赌镀锻断缎兑队对吨顿钝夺鹅额讹恶饿儿尔饵贰发罚阀珐矾钒烦范贩饭访纺飞废费纷坟奋愤粪丰枫锋风疯冯缝讽凤肤辐抚辅赋复负讣妇缚该钙盖干赶秆赣冈刚钢纲岗皋镐搁鸽阁铬个给龚宫巩贡钩沟构购够蛊顾剐关观馆惯贯广规硅归龟闺轨诡柜贵刽辊滚锅国过骇韩汉阂鹤贺横轰鸿红后壶护沪户哗华画划话怀坏欢环还缓换唤痪焕涣黄谎挥辉毁贿秽会烩汇讳诲绘荤浑伙获货祸击机积饥讥鸡绩缉极辑级挤几蓟剂济计记际继纪夹荚颊贾钾价驾歼监坚笺间艰缄茧检碱硷拣捡简俭减荐槛鉴践贱见键舰剑饯渐溅涧浆蒋桨奖讲酱胶浇骄娇搅铰矫侥脚饺缴绞轿较秸阶节茎惊经颈静镜径痉竞净纠厩旧驹举据锯惧剧鹃绢杰洁结诫届紧锦仅谨进晋烬尽劲荆觉决诀绝钧军骏开凯颗壳课垦恳抠库裤夸块侩宽矿旷况亏岿窥馈溃扩阔蜡腊莱来赖蓝栏拦篮阑兰澜谰揽览懒缆烂滥捞劳涝乐镭垒类泪篱离里鲤礼丽厉励砾历沥隶俩联莲连镰怜涟帘敛脸链恋炼练粮凉两辆谅疗辽镣猎临邻鳞凛赁龄铃凌灵岭领馏刘龙聋咙笼垄拢陇楼娄搂篓芦卢颅庐炉掳卤虏鲁赂禄录陆驴吕铝侣屡缕虑滤绿峦挛孪滦乱抡轮伦仑沦纶论萝罗逻锣箩骡骆络妈玛码蚂马骂吗买麦卖迈脉瞒馒蛮满谩猫锚铆贸么霉没镁门闷们锰梦谜弥觅绵缅庙灭悯闽鸣铭谬谋亩钠纳难挠脑恼闹馁腻撵捻酿鸟聂啮镊镍柠狞宁拧泞钮纽脓浓农疟诺欧鸥殴呕沤盘庞国爱赔喷鹏骗飘频贫苹凭评泼颇扑铺朴谱脐齐骑岂启气弃讫牵扦钎铅迁签谦钱钳潜浅谴堑枪呛墙蔷强抢锹桥乔侨翘窍窃钦亲轻氢倾顷请庆琼穷趋区躯驱龋颧权劝却鹊让饶扰绕热韧认纫荣绒软锐闰润洒萨鳃赛伞丧骚扫涩杀纱筛晒闪陕赡缮伤赏烧绍赊摄慑设绅审婶肾渗声绳胜圣师狮湿诗尸时蚀实识驶势释饰视试寿兽枢输书赎属术树竖数帅双谁税顺说硕烁丝饲耸怂颂讼诵擞苏诉肃虽绥岁孙损笋缩琐锁獭挞抬摊贪瘫滩坛谭谈叹汤烫涛绦腾誊锑题体屉条贴铁厅听烃铜统头图涂团颓蜕脱鸵驮驼椭洼袜弯湾顽万网韦违围为潍维苇伟伪纬谓卫温闻纹稳问瓮挝蜗涡窝呜钨乌诬无芜吴坞雾务误锡牺袭习铣戏细虾辖峡侠狭厦锨鲜纤咸贤衔闲显险现献县馅羡宪线厢镶乡详响项萧销晓啸蝎协挟携胁谐写泻谢锌衅兴汹锈绣虚嘘须许绪续轩悬选癣绚学勋询寻驯训讯逊压鸦鸭哑亚讶阉烟盐严颜阎艳厌砚彦谚验鸯杨扬疡阳痒养样瑶摇尧遥窑谣药爷页业叶医铱颐遗仪彝蚁艺亿忆义诣议谊译异绎荫阴银饮樱婴鹰应缨莹萤营荧蝇颖哟拥佣痈踊咏涌优忧邮铀犹游诱舆鱼渔娱与屿语吁御狱誉预驭鸳渊辕园员圆缘远愿约跃钥岳粤悦阅云郧匀陨运蕴酝晕韵杂灾载攒暂赞赃脏凿枣灶责择则泽贼赠扎札轧铡闸诈斋债毡盏斩辗崭栈战绽张涨帐账胀赵蛰辙锗这贞针侦诊镇阵挣睁狰帧郑证织职执纸挚掷帜质钟终种肿众诌轴皱昼骤猪诸诛烛瞩嘱贮铸筑驻专砖转赚桩庄装妆壮状锥赘坠缀谆浊兹资渍踪综总纵邹诅组钻致钟么为只凶准启板里雳余链泄';
}
function FTPYStr()
{
	return '皚藹礙愛翺襖奧壩罷擺敗頒辦絆幫綁鎊謗剝飽寶報鮑輩貝鋇狽備憊繃筆畢斃閉邊編貶變辯辮鼈癟瀕濱賓擯餅撥缽鉑駁蔔補參蠶殘慚慘燦蒼艙倉滄廁側冊測層詫攙摻蟬饞讒纏鏟産闡顫場嘗長償腸廠暢鈔車徹塵陳襯撐稱懲誠騁癡遲馳恥齒熾沖蟲寵疇躊籌綢醜櫥廚鋤雛礎儲觸處傳瘡闖創錘純綽辭詞賜聰蔥囪從叢湊竄錯達帶貸擔單鄲撣膽憚誕彈當擋黨蕩檔搗島禱導盜燈鄧敵滌遞締點墊電澱釣調叠諜疊釘頂錠訂東動棟凍鬥犢獨讀賭鍍鍛斷緞兌隊對噸頓鈍奪鵝額訛惡餓兒爾餌貳發罰閥琺礬釩煩範販飯訪紡飛廢費紛墳奮憤糞豐楓鋒風瘋馮縫諷鳳膚輻撫輔賦複負訃婦縛該鈣蓋幹趕稈贛岡剛鋼綱崗臯鎬擱鴿閣鉻個給龔宮鞏貢鈎溝構購夠蠱顧剮關觀館慣貫廣規矽歸龜閨軌詭櫃貴劊輥滾鍋國過駭韓漢閡鶴賀橫轟鴻紅後壺護滬戶嘩華畫劃話懷壞歡環還緩換喚瘓煥渙黃謊揮輝毀賄穢會燴彙諱誨繪葷渾夥獲貨禍擊機積饑譏雞績緝極輯級擠幾薊劑濟計記際繼紀夾莢頰賈鉀價駕殲監堅箋間艱緘繭檢堿鹼揀撿簡儉減薦檻鑒踐賤見鍵艦劍餞漸濺澗漿蔣槳獎講醬膠澆驕嬌攪鉸矯僥腳餃繳絞轎較稭階節莖驚經頸靜鏡徑痙競淨糾廄舊駒舉據鋸懼劇鵑絹傑潔結誡屆緊錦僅謹進晉燼盡勁荊覺決訣絕鈞軍駿開凱顆殼課墾懇摳庫褲誇塊儈寬礦曠況虧巋窺饋潰擴闊蠟臘萊來賴藍欄攔籃闌蘭瀾讕攬覽懶纜爛濫撈勞澇樂鐳壘類淚籬離裏鯉禮麗厲勵礫曆瀝隸倆聯蓮連鐮憐漣簾斂臉鏈戀煉練糧涼兩輛諒療遼鐐獵臨鄰鱗凜賃齡鈴淩靈嶺領餾劉龍聾嚨籠壟攏隴樓婁摟簍蘆盧顱廬爐擄鹵虜魯賂祿錄陸驢呂鋁侶屢縷慮濾綠巒攣孿灤亂掄輪倫侖淪綸論蘿羅邏鑼籮騾駱絡媽瑪碼螞馬罵嗎買麥賣邁脈瞞饅蠻滿謾貓錨鉚貿麽黴沒鎂門悶們錳夢謎彌覓綿緬廟滅憫閩鳴銘謬謀畝鈉納難撓腦惱鬧餒膩攆撚釀鳥聶齧鑷鎳檸獰甯擰濘鈕紐膿濃農瘧諾歐鷗毆嘔漚盤龐國愛賠噴鵬騙飄頻貧蘋憑評潑頗撲鋪樸譜臍齊騎豈啓氣棄訖牽扡釺鉛遷簽謙錢鉗潛淺譴塹槍嗆牆薔強搶鍬橋喬僑翹竅竊欽親輕氫傾頃請慶瓊窮趨區軀驅齲顴權勸卻鵲讓饒擾繞熱韌認紉榮絨軟銳閏潤灑薩鰓賽傘喪騷掃澀殺紗篩曬閃陝贍繕傷賞燒紹賒攝懾設紳審嬸腎滲聲繩勝聖師獅濕詩屍時蝕實識駛勢釋飾視試壽獸樞輸書贖屬術樹豎數帥雙誰稅順說碩爍絲飼聳慫頌訟誦擻蘇訴肅雖綏歲孫損筍縮瑣鎖獺撻擡攤貪癱灘壇譚談歎湯燙濤縧騰謄銻題體屜條貼鐵廳聽烴銅統頭圖塗團頹蛻脫鴕馱駝橢窪襪彎灣頑萬網韋違圍爲濰維葦偉僞緯謂衛溫聞紋穩問甕撾蝸渦窩嗚鎢烏誣無蕪吳塢霧務誤錫犧襲習銑戲細蝦轄峽俠狹廈鍁鮮纖鹹賢銜閑顯險現獻縣餡羨憲線廂鑲鄉詳響項蕭銷曉嘯蠍協挾攜脅諧寫瀉謝鋅釁興洶鏽繡虛噓須許緒續軒懸選癬絢學勳詢尋馴訓訊遜壓鴉鴨啞亞訝閹煙鹽嚴顔閻豔厭硯彥諺驗鴦楊揚瘍陽癢養樣瑤搖堯遙窯謠藥爺頁業葉醫銥頤遺儀彜蟻藝億憶義詣議誼譯異繹蔭陰銀飲櫻嬰鷹應纓瑩螢營熒蠅穎喲擁傭癰踴詠湧優憂郵鈾猶遊誘輿魚漁娛與嶼語籲禦獄譽預馭鴛淵轅園員圓緣遠願約躍鑰嶽粵悅閱雲鄖勻隕運蘊醞暈韻雜災載攢暫贊贓髒鑿棗竈責擇則澤賊贈紮劄軋鍘閘詐齋債氈盞斬輾嶄棧戰綻張漲帳賬脹趙蟄轍鍺這貞針偵診鎮陣掙睜猙幀鄭證織職執紙摯擲幟質鍾終種腫衆謅軸皺晝驟豬諸誅燭矚囑貯鑄築駐專磚轉賺樁莊裝妝壯狀錐贅墜綴諄濁茲資漬蹤綜總縱鄒詛組鑽緻鐘麼為隻兇準啟闆裡靂餘鍊洩';
}
function Traditionalized(cc){
	var str='',ss=JTPYStr(),tt=FTPYStr();
	for(var i=0;i<cc.length;i++)
	{
		if(cc.charCodeAt(i)>10000&&ss.indexOf(cc.charAt(i))!=-1)str+=tt.charAt(ss.indexOf(cc.charAt(i)));
  		else str+=cc.charAt(i);
	}
	return str;
}
function Simplized(cc){
	var str='',ss=JTPYStr(),tt=FTPYStr();
	for(var i=0;i<cc.length;i++)
	{
		if(cc.charCodeAt(i)>10000&&tt.indexOf(cc.charAt(i))!=-1)str+=ss.charAt(tt.indexOf(cc.charAt(i)));
  		else str+=cc.charAt(i);
	}
	return str;
}
function F2J()
{
	if(StranLink_Obj=="繁")
	StranLink_Obj="简";
	else
	StranLink_Obj="繁";
	setTimeout("StranBody()",StranIt_Delay);

	}
//繁简转换结束
//自添内容结束



window._isIE = (navigator.appName == "Microsoft Internet Explorer");
if(window._isIE) {
	if(navigator.userAgent.indexOf("Opera")>-1) window._isIE = null;
	if(navigator.userAgent.indexOf("Windows NT 6.0")>-1) window._isVista = true;
	else window._isVista = false;
}
else {
	if(navigator.userAgent.indexOf("Gecko")==-1) window._isIE = null;
}
function $(_sId){
	return document.getElementById(_sId);
}

var EditorEvent=new Array();

/// Word////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

EDiaryEditor = {
	initialize: function (sEditorID, sParentID, bWordMode, sContent) {
		this.initView(sParentID);
		this.initControl(bWordMode, sContent);
	},
	config: {node:{}, core:{}, frame:{}},
	getElement: function() {
		var _this = this;
		var element = null;
		var sel;
		var range;
		
		if(window._isIE) {
			sel = _this.iframe.contentWindow.document.selection;
			switch(sel.type.toLowerCase()) {
				case "none":
				case "text": {
					range = sel.createRange();
					element = range.parentElement();
					break;
				}
				case "control": {
					var ranges = sel.createRange();
					element = ranges.item(0);
					break;
				}
			}
		}
		else
		{
			sel = _this.iframe.contentWindow.getSelection();
			if(sel.rangeCount > 0)
			{
				range = sel.getRangeAt(0);
				if(range.startContainer == range.endContainer)
				{
					if(range.startContainer.nodeType != 3)
					{
						element = range.startContainer.childNodes[range.startOffset];
					}
					else element = range.startContainer;
				}
				else element = range.commonAncestorContainer;
			}
			if(element && element.nodeType == 3) element = element.parentNode;
		}
		return element;
	},
	initView: function (sParentID) {
		var _this = this;
		var hei=document.body.clientHeight-75;//
		var _toolbarStr = "\
			<div id='EDiaryEditor'style='width: 100%;height:"+document.body.clientHeight+"px;border:#333333 solid 1px;'>\
				<div id='EDiaryEditorToolBar' style='position: relative; width: 100%; height: 69px; background-image: url(images/editor/toolbar_bg.gif);background-repeat: no-repeat;background-color:#d7e3f1'>\
					<div id='EDiaryEditorFontFamilyMenu' title='字体' style='position: absolute; left: 80px; top: 12px; width: 92px; height: 18px; line-height: 20px; padding-left: 4px; cursor: pointer;' action='Family' unselectable='on'>字体</div>\
					<div id='EDiaryEditorFontSizeMenu' title='字号' style='position: absolute; left: 177px; top: 12px; width: 66px; height: 18px; line-height: 20px; padding-left: 4px; cursor: pointer;' action='Size' unselectable='on'>字号</div>\
					<div id='EDiaryEditorFontStyleMenu' title='段落' style='position: absolute; left: 245px; top: 12px; width: 66px; height: 18px; line-height: 20px; padding-left: 4px; cursor: pointer;' action='Style' unselectable='on'>段落</div>\
				</div>\
				<div style='width: 100%;height:"+hei+"px;' id='EDiaryEditorContent'>\
					<iframe id='editor_body_area' name='editor_body_area' style='width: 100%;height:"+hei+"px;border-width: 0px; overflow-x: atuo; display: nones;' frameborder='0'></iframe>\
					<textarea id='editor_body_textarea' name='editor_body' style='width: 100%;height:"+hei+"px; border-width: 0px; padding-top:8px; display: none;'></textarea>\
					<input type='hidden' name='char_count' value='-1' id='EDiaryEditorStrLen'>\
				</div>\
			</div>\
		";
/*<div style='width: 100%; height: 1px;background-color:#CCCCCC; display:none;'>\
					<div style='float: left; padding-top: 0px;'><input type='checkbox' id='ModeCheck'><label for='ModeCheck'>显示源代码</label></div>\
				</div>\*/
//document.getElementById("EDiaryEditorContent").style.height=hei;
		//addEvent(window,"onresize",onResize);
		
		//G("EDiaryEditorContent").sytle.height=hei;
		//G("editor_body_area").sytle.height=hei;
		this.addHTML($(sParentID), _toolbarStr);

		var _toolBarInfo = [
			{l: 11, t: 12, w: 35, h: 51, a: "粘贴", n: "paste"},
			{l: 46, t: 12, w: 21, h: 24, a: "剪切", n: "cut"},
			{l: 46, t: 36, w: 21, h: 27, a: "复制", n: "copy"},
			{l: 77, t: 41, w: 23, h: 23, a: "撤销", n: "undo"},
			{l: 102, t: 41, w: 23, h: 23, a: "重做", n: "redo"},
			{l: 133, t: 41, w: 23, h: 23, a: "粗体", n: "bold"},
			{l: 158, t: 41, w: 24, h: 23, a: "斜体", n: "italic"},
			{l: 184, t: 41, w: 24, h: 23, a: "下划线", n: "underline"},
			{l: 210, t: 41, w: 24, h: 23, a: "文字颜色", n: "forecolor", c: "FColor"},
			{l: 236, t: 41, w: 24, h: 23, a: "背景颜色", n: "hilitecolor", c: "HColor"},
			{l: 262, t: 41, w: 24, h: 23, a: "横线", n: "inserthorizontalrule"},
			{l: 289, t: 39, w: 25, h: 27, a: "查找替换", n: "search"},
			//{l: 288, t: 41, w: 24, h: 23, a: "简体中文", n: "face", c: "FaceBG"},
			{l: 320, t: 41, w: 23, h: 23, a: "左对齐", n: "justifyleft"},
			{l: 345, t: 41, w: 24, h: 23, a: "居中对齐", n: "justifycenter"},
			{l: 371, t: 41, w: 24, h: 23, a: "右对齐", n: "justifyright"},
			{l: 397, t: 41, w: 24, h: 23, a: "两端对齐", n: "justifyfull"},
			{l: 429, t: 41, w: 59, h: 23, a: "图片排版", n: "justifyformat", c: "Justify"},
			{l: 320, t: 10, w: 23, h: 23, a: "编号", n: "insertorderedlist"},
			{l: 345, t: 10, w: 24, h: 23, a: "项目符号", n: "insertunorderedlist"},
			{l: 371, t: 10, w: 24, h: 23, a: "减少缩进", n: "outdent"},
			{l: 397, t: 10, w: 24, h: 23, a: "增加缩进", n: "indent"},
			{l: 429, t: 10, w: 23, h: 23, a: "插入图片", n: "img"},
			{l: 454, t: 10, w: 24, h: 23, a: "插入链接", n: "link"},
			{l: 480, t: 10, w: 24, h: 23, a: "插入表格", n: "table"},
			{l: 531, t: 10, w: 24, h: 23, a: "预览文章", n: "preview"},
			{l: 506, t: 10, w: 23, h: 23, a: "插入文本框", n: "textarea"},
			{l: 496, t: 41, w: 59, h: 23, a: "简体<->繁体", n: "gogo36"},
			{l: 563, t: 10, w: 48, h: 54, a: "段落化", n: "ParaFormatting"},
		];
		_this.config.toolbarinfo = _toolBarInfo;
		var _toolbarStr2 = new String;
		for(var key in _toolBarInfo) {
			_toolbarStr2 += "<img src='images/editor/blank.gif' title='" + _toolBarInfo[key]["a"] + "' alt='" + _toolBarInfo[key]["a"] + "' id='EDiaryEditor" + _toolBarInfo[key]["n"] + "' style='position: absolute; left: " + _toolBarInfo[key]["l"] + "px; top: " + _toolBarInfo[key]["t"] + "px; width: " + _toolBarInfo[key]["w"] + "px; height: " + _toolBarInfo[key]["h"] + "px;' func='" + _toolBarInfo[key]["n"] + "' action='" + _toolBarInfo[key]["c"] + "'>";
		}
		this.addHTML($("EDiaryEditorToolBar"), _toolbarStr2);
		
		var _toolMenuInfo = {
			Family: [
				{t: "宋体"},
				{t: "黑体"},
				{t: "隶书"},
				{t: "楷体"},
				{t: "幼圆"},
				{t: "Arial"},
				{t: "Impact"},
				{t: "Georgia"},
				{t: "Verdana"},
				{t: "Courier New"},
				{t: "Times New Roman"}
			],
			Size: [
		    	{t: "10px",n:"(六号)"},
				{t: "12px",n:"(小五)"},
				{t: "14px",n:"(五号)"},
				{t: "16px",n:"(小四)"},
				{t: "18px",n:""},
				{t: "20px",n:"(小三)"},
				{t: "22px",n:""},
				{t: "24px",n:"(小二)"},
				{t: "32px",n:"(小一)"},
				{t: "56px",n:"(初号)"}
			],
			Style: [
                {t: "div",n:"取消段落", s: "14"},     
                {t: "H1",n:"段落1", s: "32"},
				{t: "H2",n:"段落2", s: "24"},
				{t: "H3",n:"段落3", s: "18"},
				{t: "H4",n:"段落4", s: "16"},
				{t: "H5",n:"段落5", s: "12"},
				{t: "H6",n:"段落6", s: "10"}
			]
		};

		var _toolbarStr3 = new String;
		var node;
		for(key in _toolMenuInfo) {
			for(var key2 in _toolMenuInfo[key]) {
				node = _toolMenuInfo[key][key2];
				if(key == "Family") {
					key2 = parseInt(key2);
					if(key2 == 0) {// head
						_toolbarStr3 += "\
							<!-- Font Family Menu -->\
							<div style='cursor: default; position: absolute; width: 163px; top: 32px; left: 78px; display: none;' id='EDiaryEditorFontFamilyItem'>\
								<div style='text-align: center; height: 20px; background-image: url(images/editor/menu_title.gif); padding-top: 6px; padding-left: 6px;'><b>字体</b></div>\
									<div style=' height: 296px!important ;height: 290px; background-image: url(images/editor/menu_bg.gif);' id='EDiaryEditorFontFamilyBox'>\
						";
					}
					if(key2 < _toolMenuInfo[key].length) {// body
						_toolbarStr3 += "\
										<div style='text-align: center; background: #f4f4f4; border: 1px solid #ccc; margin: 2px; padding: 4px; width: 149px!important ; width: 158px; font-family: " + node["t"] + "' unselectable='on' action='family' value='" + node["t"] + "'>" + node["t"] + "</div>\
						";
					}
					if(key2 + 1 == _toolMenuInfo[key].length) {// foot
						_toolbarStr3 += "\
									</div>\
								<div style='height: 10px; background-image: url(images/editor/menu_foot.gif); font-size: 1px;'></div>\
							</div>\
						";
					}
				}
				if(key == "Size") {
					key2 = parseInt(key2);
					if(key2 == 0) {// head
						_toolbarStr3 += "\
							<!-- Font Size Menu -->\
							<div style='cursor: default; position: absolute; width: 163px; top: 32px; left: 175px; display: none;' id='EDiaryEditorFontSizeItem'>\
								<div style='text-align: center; height: 20px; background-image: url(images/editor/menu_title.gif); padding-top: 6px; padding-left: 6px;'><b>字号</b></div>\
									<div style='height: 388px!important ;height: 306px; background-image: url(images/editor/menu_bg.gif);' id='EDiaryEditorFontSizeBox'>\
						";
					}
					if(key2 < _toolMenuInfo[key].length) {// body
						_toolbarStr3 += "<div style='text-align: center; background: #f4f4f4; border: 1px solid #ccc; margin: 2px; padding: 4px; width: 149px!important ; width: 158px; font-size: " + node["t"] + ";' unselectable='on' action='size' value='" + node["t"] + "'>" + node["t"] + "<span unselectable='on' style='font-size:12px'>"+node["n"]+"</span></div>";
					}
					if(key2 + 1 == _toolMenuInfo[key].length) {// foot
						_toolbarStr3 += "\
									</div>\
								<div style='height: 10px; background-image: url(images/editor/menu_foot.gif); font-size: 1px;'></div>\
							</div>\
						";
					}
				}
				if(key == "Style") {
					key2 = parseInt(key2);
					if(key2 == 0) {// head
						_toolbarStr3 += "\
							<!-- Font Style Menu -->\
							<div style='cursor: default; position: absolute; width: 163px; top: 32px; left: 243px; display: none;' id='EDiaryEditorFontStyleItem'>\
								<div style='text-align: center; height: 20px; background-image: url(images/editor/menu_title.gif); padding-top: 6px; padding-left: 6px;'><b>段落</b></div>\
									<div style='height: 231px!important ;height: 187px; background-image: url(images/editor/menu_bg.gif);' id='EDiaryEditorFontStyleBox'>\
						";
					}
					if(key2 < _toolMenuInfo[key].length) {// body
						_toolbarStr3 += "<div style='text-align: center; background: #f4f4f4; border: 1px solid #ccc; margin: 2px; padding: 4px; width: 149px!important ; width: 158px; font-size: " + node["s"] + "px;' unselectable='on' action='style' value='" + node["t"] + "'>" + node["n"] + "</div>";
					}
					if(key2 + 1 == _toolMenuInfo[key].length) {// foot
						_toolbarStr3 += "\
									</div>\
								<div style='height: 10px; background-image: url(images/editor/menu_foot.gif); font-size: 1px;'></div>\
							</div>\
						";
					}
				}
			}
		}
		this.addHTML($("EDiaryEditorToolBar"), _toolbarStr3);


		var _toolbarStr5 = "\
			<div style='position: absolute; background-image: url(editor/images/blank.gif); left: 0px; top: 0px; width: " + $("EDiaryEditor").offsetWidth + "px; height: " + $("EDiaryEditor").offsetHeight + "px; display: none;' id='EDiaryEditorDialog'>\
				<div style='position: absolute; background-image: url(images/editor/dilog_bg.gif); left: 160px; top: 140px; width: 310px; height: 157px; display: none;' id='EDiaryEditorIMGDialog'>\
				<iframe src='editor/img.html'></iframe>\
				</div>\
			</div>\
		";
		//this.addHTML($("EDiaryEditorToolBar"), _toolbarStr5);
		
		var _toolbarStr6 = "<div style='position: absolute; background: #fff; left: 234px; top: 66px; display: none;' id='EDiaryEditorforecolorItem'>";
		var k = 1;
		var c = ["","#FF9999","#FFFF80","#80FF80","#80FFFF","#0080FF","#FF80C0","#FF0000","#CCCC66","#00FF40","#0099CC","#9999CC","#FF00FF","#CC3333","#FF9933","#009999","#006699","#9999FF","#990033","#990000","#FF9900","#009900","#0000FF","#0000CC","#990099","#660000","#006666","#999900","#660099","#339999","#66CCCC","#000000","#494949","#767676","#A6A6A6","#C7C7C7","#FFFFFF"];
		for(var i = 0; i < 6; i ++) {
			for(var j = 0; j < 6; j++) {
				_toolbarStr6 += ("<img src='editor/images/blank.gif' onclick='EDiaryEditor.runCMD(\"forecolor\", \"" + c[k] + "\");' style='background: " + c[k] + ";border: 1px solid #999; margin: 0px; padding: 0px; margin-top: 1px; margin-left: 1px; width: 14px; height: 14px; cursor: hand; cursor: pointer;' />");
				k ++;
			}
			_toolbarStr6 += ('<br />');
		}
		_toolbarStr6 += "</div>";
		this.addHTML($("EDiaryEditorToolBar"), _toolbarStr6);

		var _toolbarStr7 = "<div style='position: absolute; background: #fff; left: 260px; top: 66px; display: none;' id='EDiaryEditorhilitecolorItem'>";
		var k = 1;
		var c = ["","#FF9999","#FFFF80","#80FF80","#80FFFF","#0080FF","#FF80C0","#FF0000","#CCCC66","#00FF40","#0099CC","#9999CC","#FF00FF","#CC3333","#FF9933","#009999","#006699","#9999FF","#990033","#990000","#FF9900","#009900","#0000FF","#0000CC","#990099","#660000","#006666","#999900","#660099","#339999","#66CCCC","#000000","#494949","#767676","#A6A6A6","#C7C7C7","#FFFFFF"];
		for(var i = 0; i < 6; i ++) {
			for(var j = 0; j < 6; j++) {
				_toolbarStr7 += ("<img src='editor/images/blank.gif' onclick='EDiaryEditor.runCMD(\"hilitecolor\", \"" + c[k] + "\");' style='background: " + c[k] + ";border: 1px solid #999; margin: 0px; padding: 0px; margin-top: 1px; margin-left: 1px; width: 14px; height: 14px; cursor: hand; cursor: pointer;' />");
				k ++;
			}
			_toolbarStr7 += ('<br />');
		}
		_toolbarStr7 += "</div>";
		this.addHTML($("EDiaryEditorToolBar"), _toolbarStr7);

		/*var _toolbarStr8 = "<div style='position: absolute; left: 312px; top: 66px; display: none;' id='EDiaryEditorfaceItem'>\
			<a href=\"#\" id=\"StranLink\">简体中文</a>\
		</div>\
		";*/
		var _toolbarStr8="<div style='position: absolute; left: 312px; top: 66px; display: none;' id='EDiaryEditorfaceItem'></div>";
		this.addHTML($("EDiaryEditorToolBar"), _toolbarStr8);

		var _toolbarStr9 = "<div style='position: absolute; left: 0px; top: 0px; width: 621px; background: url(editor/images/blank.gif); height: 69px; display: none;' id='EDiaryEditorToolBarMask'></div>";

		this.addHTML($("EDiaryEditorToolBar"), _toolbarStr9);	

		var _toolbarStr9 = "<div style='position: absolute; left: 483px; top: 41px; display: none;' id='EDiaryEditorRsave' title='恢复上一次未成功发表内容'><img src='images/editor/rsave.gif' csrc='/images/rsave.gif' bsrc='/images/rsave_over.gif' onmouseover='this.src=this.bsrc' onmouseout='this.src=this.csrc'></div>";
		this.addHTML($("EDiaryEditorToolBar"), _toolbarStr9);
		
		var _toolbarStr4 = "\
			<div style='position: absolute; width: 198px; height: 95px; top: 66px; left: 421px; display: none; background-image: url(images/editor/justifyformat_bg.gif);' id='EDiaryEditorJustifyFormatItem'>\
				<div style='float: left; margin-left: 12px; margin-top: 29px; width: 42px; height: 50px; cursor: pointer;' id='EDiaryEditorIMGLeft' unselectable='on'></div>\
				<div style='float: left; margin-left: 11px; margin-top: 29px; width: 42px; height: 50px; cursor: pointer;' id='EDiaryEditorIMGCenter' unselectable='on'></div>\
				<div style='float: left; margin-left: 24px; margin-top: 29px; width: 43px; height: 50px; cursor: pointer;' id='EDiaryEditorIMGRight' unselectable='on'></div>\
			</div>\
		";
		this.addHTML($("EDiaryEditorToolBar"), _toolbarStr4);

		var _toolBarHash = this.config.node;
		for(var key in _toolBarInfo) {
			_toolBarHash[_toolBarInfo[key]["n"]] = $("EDiaryEditor" + _toolBarInfo[key]["n"]);
		}
		this.iframe = $("editor_body_area");
		if(window._isIE) {
			this.iframe.addBehavior("#default#userData");
			// 恢复文章内容功能模块 
			function EDiaryEditorRsave() {
				try{
					if(readCookie("EDiaryEditor_RSave") == "false")return;
					var oPersist = _this.iframe;
					oPersist.load("EDiaryEditorRsave");
					var oData = oPersist.getAttribute("Edit");
					if(oData != null && oData != "") {
					}
				}catch(e) {};
			}
			this.EDiaryEditorRsave = EDiaryEditorRsave;
			// 成功，删除保存的内容
			this.delEditorRsave = function () {
				writeCookie("EDiaryEditor_RSave", "false", 1);
				var oPersist = _this.iframe;
				oPersist.setAttribute("Edit", "");
				oPersist.save("EDiaryEditorRsave");
			}
			var delEditorRsave = this.delEditorRsave;
			if(readCookie("EDiaryEditor_RUser") == null || readCookie("EDiaryEditor_RUser") == "" || readCookie("EDiaryEditor_RUser") == "null") {
				writeCookie("EDiaryEditor_RUser", guid, 1000);
			}
			else if (readCookie("EDiaryEditor_RUser") != guid) {
				writeCookie("EDiaryEditor_RUser", "null", 1000);
				delEditorRsave();
			}
			// 定时保存文章正文内容
			this.iframe.addBehavior("#default#userData");
			setInterval(function () {
				if(readCookie("EDiaryEditor_RSave") == "false")return;
				if(_this.iframe.contentWindow.document.body.innerHTML.length > 5000) return;
				if(sState != "iframe")return;
				if(_this.iframe.style.display != "none") {// 设计模式
					if(_this.iframe.contentWindow.document.body.innerHTML.toLowerCase() == "<div>&nbsp;</div>") return;
					if(_this.iframe.contentWindow.document.body.innerHTML.toLowerCase() == "<div></div>") return;
					if(_this.iframe.contentWindow.document.body.innerHTML.toLowerCase() == "<p>&nbsp;</p>") return;
					if(_this.iframe.contentWindow.document.body.innerHTML.toLowerCase() == "<p></p>") return;
					var oPersist = _this.iframe;
					oPersist.setAttribute("Edit",_this.iframe.contentWindow.document.body.innerHTML);
					oPersist.save("EDiaryEditorRsave");
				}
				else {// 代码模式
					if($("editor_body_textarea").value.toLowerCase() == "<div>&nbsp;</div>") return;
					if($("editor_body_textarea").value.toLowerCase() == "<div></div>") return;
					if($("editor_body_textarea").value.toLowerCase() == "<p>&nbsp;</p>") return;
					if($("editor_body_textarea").value.toLowerCase() == "<p></p>") return;
					
					var oPersist = _this.iframe;
					oPersist.setAttribute("Edit",$("editor_body_textarea").value);
					oPersist.save("EDiaryEditorRsave");
				}
			}, 2000);
		}else{
			this.delEditorRsave = this.EDiaryEditorRsave = function(){}
			}
	},
	initControl: function (bWordMode, sContent) {
		var _this = this;
		
		var FontMenuFuncHash = {
			menulist: {
				Family: {obj: $("EDiaryEditorFontFamilyItem")},
				Size: {obj: $("EDiaryEditorFontSizeItem")},
				Style: {obj: $("EDiaryEditorFontStyleItem")},
				Justify: {obj: $("EDiaryEditorJustifyFormatItem")},
				FColor: {obj: $("EDiaryEditorforecolorItem")},
				HColor: {obj: $("EDiaryEditorhilitecolorItem")},
				FaceBG: {obj: $("EDiaryEditorfaceItem")}
			},
			click: function (el, _tthis) {
				var node;
				var event = window.event || el;
				var esrc = event.srcElement || event.target;
				for(var key in _tthis.menulist) {
					node = _tthis.menulist[key];
					if(esrc.getAttribute("action") == key) {
						if(key == "Justify") {
							if(!window._isIE) {
								var oSelection = _this.iframe.contentWindow.getSelection();
							}
							else {
								var oSelection = _this.iframe.contentWindow.document.selection.createRange();
							}
							var sRangeType = _this.getElement();
							if (sRangeType.tagName.toLowerCase() != "img"){
								alert('请选中图片后操作!')
							return;
							}
						}
						if(node["obj"].style.display == "") {
							node["obj"].style.display = "none";
						}
						else {
							node["obj"].style.display = "";
						}
					}
					else {
						node["obj"].style.display = "none";
					}
				}
			},
			hide: function (event, _this) {
				var node;
				for(var key in _this.menulist) {
					node = _this.menulist[key];
					node["obj"].style.display = "none";
				};
			}
		};
		/////////////////////////////////////////////////////////////////////////

		function hiddenDialog(event, Act) {
			if(Act == "img") {
				//$("EDiaryEditorIMGDialog").style.display = "none";
				//$("EDiaryEditorDialog").style.display = "none";
			}
		}
		function viewDialog(el, Act) {
			var event = window.event || el;
			var win;
			if(window._isIE) {
			
				if(Act == "img") {
					window.showModalDialog("editor/img.htm", window, "dialogWidth: 400px; dialogHeight: 200px; help: no; scroll: no; status: no");
				}
				if(Act == "link") {
					window.showModalDialog("editor/link.htm", window, "dialogWidth: 400px; dialogHeight: 200px; help: no; scroll: no; status: no");
				}
				if(Act == "table") {
					window.showModalDialog("editor/table.htm", window, "dialogWidth: 400px; dialogHeight: 200px; help: no; scroll: no; status: no");
				}
				if(Act == "search") {
					window.showModalDialog("editor/search.htm", window, "dialogWidth: 400px; dialogHeight: 200px; help: no; scroll: no; status: no");
				}
			}
			else {
				if(Act == "img") {
					win = window.open("editor/img.htm", null, "Width=400,Height=200");
					win.dialogArguments = window;
				}
				if(Act == "link") {
					win = window.open("editor/link.htm", null, "Width=400,Height=200");
					win.dialogArguments = window;
				}
				if(Act == "table") {
					win = window.open("editor/table.htm", null, "Width=400,Height=200");
					win.dialogArguments = window;
				}
				if(Act == "search") {
					win = window.open("editor/search.htm", null, "Width=400,Height=200");
					win.dialogArguments = window;
				}
			}

		}
		function addIMG(event, Act) {
				var html = "<img src='" + $("EDiaryEditorIMGInput").value + "'>";
				if (_this.iframe.contentWindow.document.selection.type.toLowerCase() != "none"){
					_this.iframe.contentWindow.document.selection.clear() ;
				}
				_this.iframe.contentWindow.focus();
				var oRng = _this.iframe.contentWindow.document.selection.createRange();
				oRng.pasteHTML(html);
				oRng.collapse(false);
				oRng.select();
				hiddenDialog(event, Act);
		}

		////////////////////////////////////////////////////////////
		// 需要优化
        function eventObserver(){
            var es =_this.iframe.contentWindow.document.body.keyupEvents;
				/* 字体预设
                if(es.fontsize){
                    reaplceFontName("fontsize",es.fontsize)
                }
				*/
                if(es.fontname){
                    reaplceFontName("fontname",es.fontname)
                }
        }
        function formatFont(what, v){
            var idocument= _this.iframe.contentWindow.document;

            if(window._isIE) {
				if(v == "楷体" && !window._isVista) {
					v = "楷体_GB2312";
				}
                idocument.execCommand("fontname", "", "EDiaryEditor_Temp_FontName");
                 if(!idocument.body.keyupEvents)
                    idocument.body.keyupEvents=new Array();
                 if( idocument.selection.type!="Text"){
                     idocument.body.keyupEvents[what]=v;
                     idocument.body.onkeyup=eventObserver;
                 }else{
                     reaplceFontName(what,v);
                 }
            }
			else {
				switch(what){
					case "fontname":
						_this.iframe.contentWindow.document.execCommand("fontname", "", v);
						break;
					case "fontsize":
						v = parseInt(v) / 6;
						_this.iframe.contentWindow.document.execCommand("fontsize", "", v);
						break;
					default:
						break;
				}
			}
		}
        function reaplceFontName(what,v){
            var idocument=_this.iframe.contentWindow.document;
            var es=idocument.body.keyupEvents;
            var a_Font = idocument.body.getElementsByTagName("font");
                  for (var i = 0; i < a_Font.length; i++){
                        var o_Font = a_Font[i];
                        if (o_Font.getAttribute("face") == "EDiaryEditor_Temp_FontName"){
                             delInFont(o_Font, what);
                             setStyleValue(o_Font, what, v);
                            es[what]=null;
                            if(!es.fontsize && !es.fontname)
                                 o_Font.removeAttribute("face");
                       }
                 }
         }
        function delInFont(obj, what){
			var o_Children = obj.children;
			for (var j = 0; j < o_Children.length; j++){
				setStyleValue(o_Children[j], what, "");
				delInFont(o_Children[j], what);

				if (o_Children[j].style.cssText == ""){
					if ((o_Children[j].tagName == "FONT") || (o_Children[j].tagName == "SPAN")){
						o_Children[j].outerHTML = o_Children[j].innerHTML;
					}
				}
			}
		}
		function setStyleValue(obj, what, v){
			switch(what){
				case "fontname":
					obj.style.fontFamily = v;
					break;
				case "fontsize":
					obj.style.fontSize = v;
					break;
				default:
					break;
			}
		}
		////////////////////////////////////////////////////////
		function setMenuFunc(node) {
			node.onclick = function () {
				if(this.getAttribute("action") == "family") {
					formatFont("fontname", this.getAttribute("value"));
				}
				if(this.getAttribute("action") == "size") {
					formatFont("fontsize", this.getAttribute("value"));
				}
				if(this.getAttribute("action") == "style") {
					_this.runCMD("formatblock", "<" + this.getAttribute("value") + ">");
						
				}
			}
			node.onmouseover = function () {
				this.style.border = "solid #f90 1px";
				this.style.background = "#fff";
			}
			node.onmouseout = function () {
				this.style.border = "solid #ccc 1px";
				this.style.background = "#f4f4f4";
			}
		}
		var nDiv = $("EDiaryEditorFontFamilyBox").getElementsByTagName("div");
		for(var i = 0; i < nDiv.length; i ++) {
			setMenuFunc(nDiv[i]);
		}
		
		var nDiv = $("EDiaryEditorFontSizeBox").getElementsByTagName("div");
		for(var i = 0; i < nDiv.length; i ++) {
			setMenuFunc(nDiv[i]);
		}
		
		var nDiv = $("EDiaryEditorFontStyleBox").getElementsByTagName("div");
		for(var i = 0; i < nDiv.length; i ++) {
			setMenuFunc(nDiv[i]);
		}
		function formatIMG(el, Act) {
			var event = window.event || el;
			if(window.Event) {
				var oSelection = _this.iframe.contentWindow.getSelection();
			}
			else {
				var oSelection = _this.iframe.contentWindow.document.selection.createRange();
			}
			
			var sRangeType = _this.getElement();
			if (sRangeType.tagName.toLowerCase() == "img"){
				if(Act == "left") {
					sRangeType.style.margin = "4px";
					sRangeType.style.float = "left";
					sRangeType.style.display = "";
					sRangeType.style.textAlign = "";
				}
				if(Act == "center") {
					sRangeType.style.margin = "4px auto";
					sRangeType.style.display = "block";
					sRangeType.style.float = "";
					sRangeType.style.textAlign = "center";
					sRangeType.setAttribute("align", "");
				}
				if(Act == "right") {
					sRangeType.style.margin = "4px";
					sRangeType.style.float = "right";
					sRangeType.style.display = "";
					sRangeType.style.textAlign = "";
				}
				_this.iframe.contentWindow.document.body.innerHTML = _this.iframe.contentWindow.document.body.innerHTML;
			}
			else {
				alert("请选中图片后操作!");
			}
		}
		function swapMode(event, Act) {
			if(Act == "code") {
				$("editor_body_textarea").style.display = "";
				$("editor_body_area").style.display = "none";
				$("editor_body_textarea").value = _this.iframe.contentWindow.document.body.innerHTML;
				$("EDiaryEditorToolBarMask").style.display = "";
				var info = _this.config.toolbarinfo;
				for(var key in info) {
					$("EDiaryEditor" + info[key]["n"]).className = "EDiaryEditorDisable";
				}
				$("EDiaryEditorFontFamilyMenu").className = "EDiaryEditorDisable";
				$("EDiaryEditorFontSizeMenu").className = "EDiaryEditorDisable";
				$("EDiaryEditorFontStyleMenu").className = "EDiaryEditorDisable";
				//$("ModeCheck").checked = true;显示源代码
			}
			else {
				$("editor_body_textarea").style.display = "none";
				$("editor_body_area").style.display = "";
				_this.iframe.contentWindow.document.body.innerHTML = $("editor_body_textarea").value;
				$("EDiaryEditorToolBarMask").style.display = "none";
				var info = _this.config.toolbarinfo;
				for(var key in info) {
					$("EDiaryEditor" + info[key]["n"]).className = "";
				}
				$("EDiaryEditorFontFamilyMenu").className = "";
				$("EDiaryEditorFontSizeMenu").className = "";
				$("EDiaryEditorFontStyleMenu").className = "";
				$("ModeCheck").checked = false;
			}
		}
		_this.swapMode = swapMode;
		/*$("ModeCheck").onclick = function (event) {
			event = event || window.event;
			if(this.checked == true)swapMode(event, "code");
			else swapMode(event, "design");

		}显示源代码*/
		var _imgArr = {};
		var node;
		for(var key in this.config.node) {
			node = this.config.node[key];
			_imgArr[key] = new Image;
			_imgArr[key].src = "images/editor/" + key + ".gif";
			_imgArr[key + "_over"] = new Image;
			_imgArr[key + "_over"].src = "images/editor/" + key + "_over.gif";
			node.src = _imgArr[key].src;
			node.bname = key;
			node.onmouseover = function () {
				this.src = _imgArr[this.bname + "_over"].src;
			}
			node.onmouseout = function () {
				this.src = _imgArr[this.bname].src;
			}
			node.onclick = function () {
				_this.runCMD(this.bname);
			}
		}
		//$("EDiaryEditorface").onclick = 
		$("EDiaryEditorhilitecolor").onclick = $("EDiaryEditorforecolor").onclick = $("EDiaryEditorjustifyformat").onclick = $("EDiaryEditorFontStyleMenu").onclick = $("EDiaryEditorFontSizeMenu").onclick = $("EDiaryEditorFontFamilyMenu").onclick = function (event) {
			FontMenuFuncHash.click(event, FontMenuFuncHash);
			event = event || window.event;
			if(window._isIE){
				event.cancelBubble = true;
			}
			else {
				event.stopPropagation();
			}
		}
		$("EDiaryEditorIMGLeft").onmouseup = function (event) {
            formatIMG(event, "left");
		}
		$("EDiaryEditorIMGCenter").onmouseup = function (event) {
		        formatIMG(event, "center");
		}
		$("EDiaryEditorIMGRight").onmouseup = function (event) {
		        formatIMG(event, "right");
		}		
		$("EDiaryEditorimg").onclick = function (event) {
			viewDialog(event, "img");
		}
		$("EDiaryEditorsearch").onclick = function (event) {
			viewDialog(event, "search");
		}
		$("EDiaryEditorlink").onclick = function (event) {
			viewDialog(event, "link");
		}
		$("EDiaryEditortable").onclick = function (event) {
			viewDialog(event, "table");
		}
		var _iframeHTML = "\
		<html>\
		<head>\
		<style>\
		body {\
			background: #ffffff;\
			margin: 0px;\
			padding: 8px 5px 2px 12px;\
			font-size: 14px;\
			overflow: auto;\
			scrollbar-face-color: #fff;\
			scrollbar-highlight-color: #c1c1bb;\
			scrollbar-shadow-color: #c1c1bb;\
			scrollbar-3dlight-color: #ebebe4;\
			scrollbar-arrow-color: #cacab7;\
			scrollbar-track-color: #f4f4f0;\
			scrollbar-darkshadow-color: #ebebe4;\
			word-wrap: break-word;\
			font-family: '宋体', 'Courier New';\
		}\
		p {\
			margin: 0px;\
		}\
		li, div, span , p {\
 			 line-height:1.5;\
		}\
		</style>\
		<script language=\"JavaScript\">\
			function resizeImg(_oObj, _iWidth){\
				var tMark = true;var iWidth = 0;var sOuterHtml;var aNode = _oObj.attributes;\
				for(var i = 0; i < aNode.length; i++){if(aNode[i].specified){if(aNode[i].name == \"width\" || aNode[i].name == \"height\"){tMark = false;}}}\
				if(tMark){if(_iWidth){setTimeout(\"resize()\",500);}}\
				this.resize = function(){if(_oObj.width > _iWidth){_oObj.width = _iWidth;}}\
			}\
		<\/script>\
		</head>\
		<body>" + (sContent ? sContent : "") + "</body>\
		</html>";
		_this.iframe.contentWindow.document.open();
		_this.iframe.contentWindow.document.write(_iframeHTML);
		_this.iframe.contentWindow.document.close();
		if(window._isIE){
			_this.iframe.contentWindow.document.body.contentEditable = true;
		}else{
			_this.iframe.contentWindow.document.designMode = "on";
		}
		this.cacheIframe = document.createElement("iframe");
		this.cacheIframe.style.visibility = "hidden";
		this.cacheIframe.style.position = "absolute";
		document.body.appendChild(this.cacheIframe);
		_this.iframeWindow = _this.iframe.contentWindow;
		_this.iframeDocument = _this.iframeWindow.document;

		// 初始化IFRAME中的事件 
		this.iframeEventCore.init(this);
		_this.iframe.contentWindow.document.onclick = document.onclick = function (event) {
			event = event || window.event;
			FontMenuFuncHash.hide(event, FontMenuFuncHash);
		}
		// zly, moz 下点击编辑区清除菜单无效, try 解决单纯判断浏览器引起的误差。
		try{
			_this.iframe.contentWindow.document.addEventListener('click', function (event) {
				event = event || window.event;
				FontMenuFuncHash.hide(event, FontMenuFuncHash);
			},true);
		}catch(e){};

		setTimeout(function () {
		_this.iframe.contentWindow.document.body.onpaste = function (event) {
			var clearFromWord = function(html) {
				// for Word2000+
				html = html.replace(/<\/?SPAN[^>]*>/gi, "" );
				html = html.replace(/<(\w[^>]*) class=([^ |>]*)([^>]*)/gi, "<$1$3");
				html = html.replace(/<(\w[^>]*) style="([^"]*)"([^>]*)/gi, "<$1$3");
				html = html.replace(/<(\w[^>]*) lang=([^ |>]*)([^>]*)/gi, "<$1$3");
				html = html.replace(/<\\?\?xml[^>]*>/gi, "");
				html = html.replace(/<\/?\w+:[^>]*>/gi, "");
				// for Word2000
				html = html.replace(/<img+.[^>]*>/gi, "");
				return html;
			};
			if(window._isIE) {
				var pasteData = function () {
					var tif = _this.cacheIframe
					document.body.appendChild(tif);
					tlf = tif.contentWindow.document;
					tlf.body.innerHTML = "";
					tlf.body.createTextRange().execCommand("Paste");
					var html = tlf.body.innerHTML;
					var len = html.indexOf("&nbsp;");
					if(len == 0) html = html.replace(/\&nbsp;/i, "");
					var htmlData = html;
					tlf.body.innerHTML = "";
					return htmlData;
				}
				pasteData = pasteData();
				if(pasteData && pasteData.length > 0) {
					var wordPattern = /<\w[^>]* class="?MsoNormal"?/gi;
					if(wordPattern.test(pasteData)) {
						if(confirm("文章有多余代码，可能影响顺利发表，是否确认清除？\r\n\r\n提示：您的文字将完整保留。")) {
							pasteData = clearFromWord(pasteData);
						} 
						else {	
							pasteData = pasteData.replace(/<img+.[^>]*>/gi, "");
							pasteData = pasteData.replace(/<\/?\w+:imagedata[^>]*>/gi, "");
							pasteData = pasteData.replace(/<\/?\w+:shape[^>]*>/gi, "");
						}
					}
					var oRTE = _this.iframe.contentWindow;
					var oRng = oRTE.document.selection.createRange();
					oRng.pasteHTML(pasteData);
				}
				return false;
			}
			return false;
		}
		}, 500);
		$("EDiaryEditorpreview").onclick = function () {
			$("editor_body_textarea").value = _this.iframe.contentWindow.document.body.innerHTML;
			article_preview();
		}
		if(window._isIE)setTimeout(this.EDiaryEditorRsave, 500);
	},
	iframeEventCore: {
		init: function (_this) {
			var tthis = this;
			_this.iframe.contentWindow.document.onmousedown = function () {
				tthis.mousedown(_this.iframe.contentWindow.event, _this);
			}
			_this.iframe.contentWindow.document.onkeyup = function () {
				tthis.keyup(_this.iframe.contentWindow.event, _this);
			}
			setInterval(function () {
				tthis.imgsize(_this);
			}, 2000);
		},
		keyup: function (event, _this) {
		},
		imgsize: function (_this) {
			var o = _this.iframe.contentWindow.document.getElementsByTagName("img");
			var w, h;
			for(var i = 0; i < o.length; i ++) {
				w = o[i].width;
				h = o[i].height;
				if(w > 500) {
					o[i].style.width = 500;
					o[i].style.height = Math.floor(o[i].width * (h / w));
				}
			}
		},
		mousedown: function (el, _this) {
			var tthis = this;
			var event = window.event || el;
			var esrc = event.srcElement || event.target;
			if(esrc.tagName.toLowerCase() == "img") {
				this.img = esrc;
				this.w = this.t_w = this.img.offsetWidth;
				this.h = this.t_h = this.img.offsetHeight;
				this.resizeEnd = false;
				this.img.onresize = function () {
					tthis.img = this;
					tthis.resize(event, _this);
					
				}
			}
		},
		resize: function (event, _this) {
			var tthis = this;
			if((this.t_w != this.img.offsetWidth || this.t_h != this.img.offsetHeight) && this.resizeEnd == false) {
				setTimeout(function () {
					tthis.timeout(tthis);
				}, 10);
				this.resizeEnd = true;
				this.img.onresize = null;
			}
		},
		timeout: function (_this) {
			if(Math.abs(_this.t_w - _this.img.offsetWidth) > 0) {
				_this.img.style.height = Math.floor(_this.img.offsetWidth * (_this.h / _this.w));
			}
			if(Math.abs(_this.t_h - _this.img.offsetHeight) > 0) {
				_this.img.style.width = Math.floor(_this.img.offsetHeight * (_this.w / _this.h));
			}
			_this.t_w = _this.img.offsetWidth;
			_this.t_h = _this.img.offsetHeight;
		}
	},
	runCMD: function (CMD, sValue) {
		var _this = this;
		if(CMD == "" || CMD == null)return;
		else if(CMD == "ParaFormatting") {
			var oBody	= _this.iframe.contentWindow.document.body;
			var oChild	= oBody.childNodes;
			for(var i = 0; i < oChild.length; i++){
				if(oChild[i].tagName){
					
					// 去掉首尾空格
					oChild[i].innerHTML	= oChild[i].innerHTML.split('&nbsp;').join('');
					oChild[i].innerHTML	= oChild[i].innerHTML.replace(/(^[ |　|]*)|([ |　|]*$)/g, "");
					oChild[i].innerHTML	= oChild[i].innerHTML.split('').join('&nbsp;');
					
					// 是否已经排过版,使用 2em 会使段落排版混乱［h1,h2混］,可设计默认 28 像素。通过计算子节点 fontSize 方式同样有此问题
					if(!oChild[i].style.textIndent){
						oChild[i].style.textIndent	= '2em';
					// 默认排版前
					}else{
						oChild[i].style.textIndent	= '';
					}
				// 纯文本
				}else{
					oBody.innerHTML = '<div style="text-indent:2em;">' + oBody.innerHTML.replace(/(^[ |　]*)|([ |　]*$)/g, ""); + '</div>';
				}
			}
		}
		else if(CMD == "justifyformat" || CMD == "img" || CMD == "link" || CMD == "table" || CMD == "face") {
			
		}
		else if(CMD == "forecolor") {
			_this.iframe.contentWindow.document.execCommand("forecolor", false, sValue);
		}
		else if(CMD == "hilitecolor") {
			_this.iframe.contentWindow.document.execCommand("backcolor", false, sValue);
		}
		else if(CMD == "gogo36") {
			F2J();
			//return;
			/*var oRTE = _this.iframe.contentWindow;
			var rng;
			if(window._isIE) {
				var selection = oRTE.document.selection; 
				if (selection != null) {
					rng = selection.createRange();
				}
			}
			else {
				var selection = oRTE.getSelection();
				rng = selection.getRangeAt(selection.rangeCount - 1).cloneRange();
				rng.text = rng.toString();
			}
			//var html = "<a href='/search.php?site=soft&id=unll&name=" + encodeURI(rng.text) + "' target='_blank'> <FONT color==#0080ff>" + rng.text  + "</FONT></a>";
			var html="{val:变量名称}";
			if(window._isIE) {
				var oSelection = oRTE.document.selection.createRange();
				var sRangeType = oRTE.document.selection.type;
				if (sRangeType == "Text") {
					try{
						oRTE.focus();
						var oRng = oRTE.document.selection.createRange();
						oRng.pasteHTML(html);
						oRng.collapse(false);
						oRng.select();
					}
					catch(e){}
				}
				else {
					alert("请选择一段文字后操作!");
				}
				
			}
			else {
				if(rng.text == "") {
					alert("请选择一段文字后操作!");
				}
				else {
					_this.iframe.contentWindow.document.execCommand("insertHTML", false, html);
				}
			}*/
		}
		else if(CMD == "cleartype") {
			if(window._isIE) {
				for(var i = 0; i < _this.iframe.contentWindow.document.all.length; i ++) {
					var node = _this.iframe.contentWindow.document.all[i];
					if(node.tagName == "IMG") {
						_this.addHTML2(node, "&lt;Sina_Temp_IMG_Editor src='" + node.src + "' width='" + node.width + "' height='" + node.height + "' border='0'&gt;");
					}
				}
				var str = _this.iframe.contentWindow.document.body.innerText;
				str = str.replace(/<Sina_Temp_IMG_Editor/g, "<img");
				_this.iframe.contentWindow.document.body.innerHTML = str;
			}
			else {
				alert("此功能暂时不支持您现在的浏览器，请使用IE浏览");
			}
		}
		else if(CMD == "textarea") {
			var _sVal;
			var frameWin = _this.iframe.contentWindow;
			var rng = {};
			if (window._isIE) {
				var selection = frameWin.document.selection; 
				if (selection != null) {
					rng = selection.createRange();
				}
			} else {
				var selection = frameWin.getSelection();
				
				rng = selection.getRangeAt(selection.rangeCount - 1).cloneRange();
				rng.text = rng.toString();
			}
			_sVal = rng.text == "" ? "请在文本框输入文字" : rng.text;
			var html = "<table style='border:1px solid #999;width:80%;font-size:12px;' align='center'><tr><td>"+ _sVal +"</td></tr></table>";
		
			frameWin.focus();
			if(window._isIE) {
				var oSelection = _this.iframe.contentWindow.document.selection.createRange();
				var sRangeType = _this.iframe.contentWindow.document.selection.type;
				
					oSelection.pasteHTML(html);
					oSelection.collapse(false);
					oSelection.select();
			}
			else {
				 _this.iframe.contentWindow.document.execCommand('insertHTML', false, html);
			}
		}
		else if (CMD == "hilitecolor") {
			if(window._isIE) this.iframe.contentWindow.document.execCommand("BackColor",sValue);
			else this.iframe.contentWindow.document.execCommand("hilitecolor",sValue);
		}
		else if (CMD == "undo" || CMD == "redo" || CMD == "cut" || CMD == "copy" || CMD == "paste") {
			if(window._isIE == true) {
				this.iframe.contentWindow.focus();
				this.iframe.contentWindow.document.execCommand(CMD, false, sValue);
				this.iframe.contentWindow.focus();
			}
			else {
				alert("该浏览器不支持本功能");
			}
		}
		else {
			this.iframe.contentWindow.focus();
			this.iframe.contentWindow.document.execCommand(CMD, false, sValue);
			this.iframe.contentWindow.focus();
		}
	},
	addHTML: function (oParentNode, sHTML) {
		if(window.addEventListener) {// for MOZ
			var oRange = oParentNode.ownerDocument.createRange();
			oRange.setStartBefore(oParentNode);
			var oFrag = oRange.createContextualFragment(sHTML);
			oParentNode.appendChild(oFrag);
		}
		else {// for IE5+
			oParentNode.insertAdjacentHTML("BeforeEnd", sHTML);
		}
	},
	addHTML2: function (oParentNode, sHTML) {
		oParentNode.insertAdjacentHTML("afterEnd", sHTML);
	},
	insertFace: function (nFaceNum) {
		var FacePath = "face/";
		this.iframe.contentWindow.focus();
		this.iframe.contentWindow.document.execCommand("InsertImage", false, FacePath + nFaceNum + ".gif");
		this.iframe.contentWindow.focus();
	},
	save: function () {
		var _this = this;
		/*if($("ModeCheck").checked == true) {
			_this.iframeEventCore.imgsize(_this);
			_this.iframe.contentWindow.document.body.innerHTML = $("editor_body_textarea").value;
			$("editor_body_textarea").value = _this.iframe.contentWindow.document.body.innerHTML;
		}
		else {*/
			$("editor_body_textarea").value = _this.iframe.contentWindow.document.body.innerHTML;
		//}
	}
};